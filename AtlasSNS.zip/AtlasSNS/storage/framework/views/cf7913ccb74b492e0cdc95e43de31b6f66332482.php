<?php $__env->startSection('content'); ?>

<?php echo Form::open(['url' => '/login']); ?>


<p>AtlasSNSへようこそ</p>

<?php echo e(Form::label('mail address')); ?>

<?php echo e(Form::text('mail',null,['class' => 'input'])); ?>

<?php echo e(Form::label('password')); ?>

<?php echo e(Form::password('password',['class' => 'input'])); ?>


<?php echo e(Form::submit('LOGIN',['class' => 'login_button'])); ?>



<p><a href="/register">新規ユーザーの方はこちら</a></p>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rv131\Dropbox\My PC (DESKTOP-U3T4CJS)\Desktop\Atlas_SNS_kobayashi\AtlasSNS\resources\views/auth/login.blade.php ENDPATH**/ ?>