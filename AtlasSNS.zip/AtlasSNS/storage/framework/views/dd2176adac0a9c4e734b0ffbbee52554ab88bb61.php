<?php $__env->startSection('content'); ?>

<?php echo Form::open(['url' => '/register']); ?>


<h2>新規ユーザー登録</h2>

<?php echo e(Form::label('ユーザー名')); ?>

<?php echo e(Form::text('username',null,['class' => 'input'])); ?>


<?php echo e(Form::label('メールアドレス')); ?>

<?php echo e(Form::text('mail',null,['class' => 'input'])); ?>


<?php echo e(Form::label('パスワード')); ?>

<?php echo e(Form::text('password',null,['class' => 'input'])); ?>


<?php echo e(Form::label('パスワード確認')); ?>

<?php echo e(Form::text('password_confirmation',null,['class' => 'input'])); ?>


<?php echo e(Form::submit('REGISTER',['class' => 'register_button'])); ?>

<?php echo Form::open(['url' => '/added']); ?>


<p><a href="/login">ログイン画面へ戻る</a></p>

<?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rv131\Dropbox\My PC (DESKTOP-U3T4CJS)\Desktop\Atlas_SNS_kobayashi\AtlasSNS\resources\views/auth/register.blade.php ENDPATH**/ ?>