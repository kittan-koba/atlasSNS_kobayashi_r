<?php $__env->startSection('content'); ?>

  <img src="<?php echo e(asset('storage/images/' .$username->images )); ?>"  width="50" height="50" >
  <p>名前：<?php echo e($username->username); ?></p>
  <p>bio：<?php echo e($username->bio); ?></p>
    <?php if(auth()->user()->isFollowing($username->id)): ?>
  <div class="">
  </div>
    <form action="<?php echo e(route('unfollow', ['id' => $username->id])); ?>" method="POST">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('DELETE')); ?>


    <button type="submit" class="btn btn-danger">フォロー解除</button>
    </form>
  <?php else: ?>
    <form action="<?php echo e(route('follow', ['id' => $username->id])); ?>" method="POST">
      <?php echo e(csrf_field()); ?>


    <button type="submit" class="btn btn-primary">フォローする</button>
    </form>
  <?php endif; ?>
<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p>名前：<?php echo e($post->user->username); ?></p>
    <p>投稿内容：<?php echo e($post->post); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rv131\Dropbox\My PC (DESKTOP-U3T4CJS)\Desktop\Atlas_SNS_kobayashi\AtlasSNS\resources\views/users/profile.blade.php ENDPATH**/ ?>