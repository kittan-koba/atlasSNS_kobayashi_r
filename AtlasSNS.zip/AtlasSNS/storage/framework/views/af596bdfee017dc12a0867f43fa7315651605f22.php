<?php $__env->startSection('content'); ?>

<form action="/search" method="get">
  <div class="border_top">
    <?php echo csrf_field(); ?>
      <input type="text" name="username" placeholder="キーワードを入力">
      <input type="submit" name="submit" value="検索">
  </div>
</form>
<div class="search-wrapper">
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div style="padding-left:20px">
                 <?php if(!empty ($message)): ?>
                    <div><?php echo e($message); ?></div>
                 <?php endif; ?>
                        <div class="search_container">
                            <div class="search_username"><?php echo e($user->username); ?></div>
                                <div class="d-flex flex-row-1">
                                    <?php if(auth()->user()->isFollowing($user->id)): ?>
                                        <img src="<?php echo e(asset('storage/images/' .auth()->user()->images )); ?>" class="" width="45px" height="45px">
                                        <form action="<?php echo e(route('unfollow', ['id' => $user->id])); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>


                                        <button type="submit" class="btn btn-danger">フォロー解除</button>
                                    </form>
                                <?php else: ?>
                                    <form action="<?php echo e(route('follow', ['id' => $user->id])); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>


                                        <button type="submit" class="btn btn-primary">フォローする</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<style></style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rv131\Dropbox\My PC (DESKTOP-U3T4CJS)\Desktop\Atlas_SNS_kobayashi\AtlasSNS\resources\views/users/search.blade.php ENDPATH**/ ?>