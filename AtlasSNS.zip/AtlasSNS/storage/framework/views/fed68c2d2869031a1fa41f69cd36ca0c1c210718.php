<?php $__env->startSection('content'); ?>

<div class="user_wrapper">
  <img src="<?php echo e(asset('storage/images/' .auth()->user()->images )); ?>"  width="40" height="40" >
  <form action="/updataprofile" method="post"  enctype='multipart/form-data'>
    <?php echo csrf_field(); ?>
    <div class="edit_wrapper">
    <div class="user_edit">
      <p class="user_text">user name </p>
      <input type="text" name="username" value="<?php echo e(auth()->user()->username); ?>" class="user_textbox" />
    </div>
    <div class="user_edit">
      <p class="user_text">mail adress</p>
      <input type="text" name="mail" value="<?php echo e(auth()->user()->mail); ?>" class="user_textbox" />
    </div>
    <div class="user_edit">
      <p class="user_text">password</p>
      <input type="text" name="password" class="user_textbox">
    </div>
      <div class="user_edit">
      <p class="user_text">password comfirm</p>
      <input type="text" name="password_confirmation" class="user_textbox">
    </div>
     <div class="user_edit">
      <p class="user_text">bio</p>
      <input type="text" name="bio" value="<?php echo e(auth()->user()->bio); ?>" class="user_textbox" >
    </div>
    <div class="user_edit">
      <p class="user_text">icon image</p>
      <div class="backgroundbox">
      <label class="filebox">
      <input type="file" name="image" class="user_textbox" >ファイルを選択
      </label>
      </div>
    </div>
    <div class="update_type">
      <input type="submit" class="update_btn" value="更新" />
      </div>
      </div>
  </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rv131\Dropbox\My PC (DESKTOP-U3T4CJS)\Desktop\Atlas_SNS_kobayashi\AtlasSNS\resources\views/users/userprofile.blade.php ENDPATH**/ ?>