<?php $__env->startSection('content'); ?>

<div id="clear">
  <div class="add">
    <p><?php echo e($username); ?>さん</p>
    <p>ようこそ！AtlasSNSへ</p>
  </div>
  <div class="add_a">
    <p>ユーザー登録が完了いたしました。</p>
    <p>早速ログインをしてみましょう!</p>
  </div>


  <p class="btn"><a href="/login">ログイン画面へ</a></p>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rv131\Dropbox\My PC (DESKTOP-U3T4CJS)\Desktop\Atlas_SNS_kobayashi\AtlasSNS\resources\views/auth/added.blade.php ENDPATH**/ ?>