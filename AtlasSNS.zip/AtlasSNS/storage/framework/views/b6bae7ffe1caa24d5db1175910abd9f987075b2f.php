<?php $__env->startSection('content'); ?>
<div class="container">
            <?php echo Form::open(['url' => '/top']); ?>

            <div class="border_top">
            <div class="newpost_content">
            <div class="newpostcontainer">
            <img src="<?php echo e(asset('storage/images/' .auth()->user()->images )); ?>" >
            <div class="form-group">
                <?php echo Form::input('text', 'newPost', null, ['required', 'class' => 'form-control', 'placeholder' => '投稿内容を入力してください。']); ?>

            </div>

            <div class=newpost_btn>
            <button type="submit" class="btn btn-success pull-right"><img src="images/post.png"></button>
          </div>
          </div>
          </div>
          </div>
            <?php echo Form::close(); ?>

            <div class="tweet-wrapper"> <!-- この辺追加 -->
                <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(auth()->user()->isFollowing($post->user_id) || auth()->user()->id == $post->user_id): ?>
                  <div style="padding:2rem; border-top: solid 1px #E6ECF0; border-bottom: solid 1px #E6ECF0;" >
                  <div class="post_container">
                <!--isFollowingのメソッドを確認する-->
                     <!-- <?php if($post -> user -> id == auth()->user()->isFollowing($post->user->id) || auth()->user()->id == $post -> user -> id): ?>
                        <p>名前：<?php echo e($post->user->username); ?></p>
                        <p>投稿内容：<?php echo e($post->post); ?></p>
                    <?php endif; ?> -->
                    <div class="creattime">
                    <?php echo e($post->created_at); ?>

                    </div>
                    <div class="post_box">
                    <img src="<?php echo e(asset('storage/images/' .$post->user->images )); ?>" width="45px" height="45px" >
                    <div class="post_box_container">
                    <?php echo e($post->user->username); ?>

                    <br>
                    <br>
                    <?php echo e($post->post); ?>

                    </div>
                    </div>

                    <div class="edit_btn">
                    <a class="js-modal-open" post="<?php echo e($post->post); ?>" post_id="<?php echo e($post->id); ?>"><img src="images/edit.png"></a>
                    <a class="btn btn-danger" href="/post/<?php echo e($post->id); ?>/delete" onclick="return confirm('こちらの投稿を削除してもよろしいでしょうか？')"><img src="images/trash.png"></a>
                    </div>
                    </div>
                    </div>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="modal js-modal">
                  <div class="modal__bg js-modal-close"></div>
                    <div class="modal__content">
                      <form action="/update" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" class="modal_id" value="<?php echo e($post->id); ?>">
                        <textarea name="post" class="modal_post"></textarea>
                        <input type="image" alt="更新" src="images/edit.png" action="/update">
                      </form>
                    </div>
                </div>
            </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rv131\Dropbox\My PC (DESKTOP-U3T4CJS)\Desktop\Atlas_SNS_kobayashi\AtlasSNS\resources\views/posts/index.blade.php ENDPATH**/ ?>