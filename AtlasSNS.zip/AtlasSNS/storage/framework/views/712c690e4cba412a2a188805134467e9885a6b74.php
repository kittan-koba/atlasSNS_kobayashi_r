<?php $__env->startSection('content'); ?>


<div class='follow-wrapper'>
  <div class="border_top">
  <h2>Follow List</h2>
  <?php $__currentLoopData = $follow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(url('/profile/' .$follows -> id )); ?>">
          <img src="<?php echo e(asset('storage/images/' .$follows->images )); ?>"  width="50" height="50" >
          <!-- <?php echo e($follows -> id); ?> -->
          </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if(auth()->user()->isFollowing($post->user->id)): ?>
    <div class="follow_post">
      <div class="creattime">
      <?php echo e($post->created_at); ?>

      </div>
      <div class="follow_post_box">
        <img src="<?php echo e(asset('storage/images/' .$follows->images )); ?>" width="45px" height="45px" >
        <div>
        <p>名前：<?php echo e($post->user->username); ?></p>
        </div>
        <div>
        <p>投稿内容：<?php echo e($post->post); ?></p>
        </div>
      </div>
    </div>
    <?php endif; ?>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rv131\Dropbox\My PC (DESKTOP-U3T4CJS)\Desktop\Atlas_SNS_kobayashi\AtlasSNS\resources\views/follows/followList.blade.php ENDPATH**/ ?>