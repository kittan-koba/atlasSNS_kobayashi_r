@extends('layouts.login')

@section('content')
<div class="container">
            {!! Form::open(['url' => '/top']) !!}
            <div class="border_top">
            <div class="newpost_content">
            <div class="newpostcontainer">
            <img src="{{ asset('storage/images/' .auth()->user()->images ) }}" >
            <div class="form-group">
                {!! Form::input('text', 'newPost', null, ['required', 'class' => 'form-control', 'placeholder' => '投稿内容を入力してください。']) !!}
            </div>

            <div class=newpost_btn>
            <button type="submit" class="btn btn-success pull-right"><img src="images/post.png"></button>
          </div>
          </div>
          </div>
          </div>
            {!! Form::close() !!}
            <div class="tweet-wrapper"> <!-- この辺追加 -->
                @foreach($post as $post)
                  @if (auth()->user()->isFollowing($post->user_id) || auth()->user()->id == $post->user_id)
                  <div style="padding:2rem; border-top: solid 1px #E6ECF0; border-bottom: solid 1px #E6ECF0;" >
                  <div class="post_container">
                <!--isFollowingのメソッドを確認する-->
                     <!-- @if ($post -> user -> id == auth()->user()->isFollowing($post->user->id) || auth()->user()->id == $post -> user -> id)
                        <p>名前：{{ $post->user->username }}</p>
                        <p>投稿内容：{{ $post->post }}</p>
                    @endif -->
                    <div class="creattime">
                    {{ $post->created_at }}
                    </div>
                    <div class="post_box">
                    <img src="{{ asset('storage/images/' .$post->user->images ) }}" width="45px" height="45px" >
                    <div class="post_box_container">
                    {{ $post->user->username }}
                    <br>
                    <br>
                    {{ $post->post }}
                    </div>
                    </div>

                    <div class="edit_btn">
                    <a class="js-modal-open" post="{{ $post->post }}" post_id="{{ $post->id }}"><img src="images/edit.png"></a>
                    <a class="btn btn-danger" href="/post/{{ $post->id }}/delete" onclick="return confirm('こちらの投稿を削除してもよろしいでしょうか？')"><img src="images/trash.png"></a>
                    </div>
                    </div>
                    </div>
                  @endif
                @endforeach
                <div class="modal js-modal">
                  <div class="modal__bg js-modal-close"></div>
                    <div class="modal__content">
                      <form action="/update" method="POST">
                        @csrf
                        <input type="hidden" name="id" class="modal_id" value="{{ $post->id }}">
                        <textarea name="post" class="modal_post"></textarea>
                        <input type="image" alt="更新" src="images/edit.png" action="/update">
                      </form>
                    </div>
                </div>
            </div>

</div>

@endsection
