@extends('layouts.login')

@section('content')

  <img src="{{ asset('storage/images/' .$username->images ) }}"  width="50" height="50" >
  <p>名前：{{ $username->username }}</p>
  <p>bio：{{ $username->bio }}</p>
    @if (auth()->user()->isFollowing($username->id))
  <div class="">
  </div>
    <form action="{{ route('unfollow', ['id' => $username->id]) }}" method="POST">
      {{ csrf_field() }}
      {{ method_field('DELETE') }}

    <button type="submit" class="btn btn-danger">フォロー解除</button>
    </form>
  @else
    <form action="{{ route('follow', ['id' => $username->id]) }}" method="POST">
      {{ csrf_field() }}

    <button type="submit" class="btn btn-primary">フォローする</button>
    </form>
  @endif
@foreach($post as $post)
    <p>名前：{{ $post->user->username }}</p>
    <p>投稿内容：{{ $post->post }}</p>
@endforeach
@endsection
