@extends('layouts.login')

@section('content')

<form action="/search" method="get">
  <div class="border_top">
    @csrf
      <input type="text" name="username" placeholder="キーワードを入力">
      <input type="submit" name="submit" value="検索">
  </div>
</form>
<div class="search-wrapper">
              @foreach($users as $user)

                <div style="padding-left:20px">
                 @if(!empty ($message))
                    <div>{{ $message }}</div>
                 @endif
                        <div class="search_container">
                            <div class="search_username">{{ $user->username }}</div>
                                <div class="d-flex flex-row-1">
                                    @if (auth()->user()->isFollowing($user->id))
                                        <img src="{{ asset('storage/images/' .auth()->user()->images ) }}" class="" width="45px" height="45px">
                                        <form action="{{ route('unfollow', ['id' => $user->id]) }}" method="POST">
                                        {{ csrf_field() }}
                                        {{ method_field('DELETE') }}

                                        <button type="submit" class="btn btn-danger">フォロー解除</button>
                                    </form>
                                @else
                                    <form action="{{ route('follow', ['id' => $user->id]) }}" method="POST">
                                        {{ csrf_field() }}

                                        <button type="submit" class="btn btn-primary">フォローする</button>
                                    </form>
                                @endif
                            </div>
                        </div>
                </div>
              @endforeach
</div>
<style></style>
@endsection
