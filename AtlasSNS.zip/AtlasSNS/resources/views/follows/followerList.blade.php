@extends('layouts.login')

@section('content')
<div class='follower-wrapper'>
  <div class="border_top">
  <h2>Follower List</h2>
  @foreach ($follower as $followers)
        <div class="">
          <a href="{{ url('/profile/' .$followers->id ) }}">
          <img src="{{ asset('storage/images/' .$followers->images ) }}" >
          </a>
        </div>
  @endforeach
      </div>
    @foreach($post as $post)
    @if (auth()->user()->isFollowed($post->user->id))
    <div class="follower_post">
      <div class="creattime">
      {{ $post->created_at }}
      </div>
        <div class="follower_post_box">
        <img src="{{ asset('storage/images/' .$followers->images ) }}" width="45px" height="45px" >
      <div>
      <p>名前：{{ $post->user->username }}</p>
    </div>
    <div>
      <p>投稿内容：{{ $post->post }}</p>
      </div>
      </div>
    </div>
    @endif
  @endforeach

</div>
@endsection
