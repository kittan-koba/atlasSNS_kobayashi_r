@extends('layouts.login')

@section('content')


<div class='follow-wrapper'>
  <div class="border_top">
  <h2>Follow List</h2>
  @foreach ($follow as $follows)
          <a href="{{ url('/profile/' .$follows -> id ) }}">
          <img src="{{ asset('storage/images/' .$follows->images ) }}"  width="50" height="50" >
          <!-- {{ $follows -> id }} -->
          </a>
  @endforeach
  </div>
  @foreach($post as $post)

    @if (auth()->user()->isFollowing($post->user->id))
    <div class="follow_post">
      <div class="creattime">
      {{ $post->created_at }}
      </div>
      <div class="follow_post_box">
        <img src="{{ asset('storage/images/' .$follows->images ) }}" width="45px" height="45px" >
        <div>
        <p>名前：{{ $post->user->username }}</p>
        </div>
        <div>
        <p>投稿内容：{{ $post->post }}</p>
        </div>
      </div>
    </div>
    @endif

  @endforeach

</div>
@endsection
